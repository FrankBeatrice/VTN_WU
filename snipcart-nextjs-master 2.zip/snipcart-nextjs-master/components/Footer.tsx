export default function Footer(){
  return (
    <footer className="footer">
      <p>
        
        <div className="footer__left">
          
        </div>
      </p>
    </footer>
  )
}